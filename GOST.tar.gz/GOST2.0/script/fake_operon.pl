#!/usr/bin/perl
#
#Description:
#

use strict;
use warnings;
use Data::Dumper;

my $usage = <<HERE;
Generate a fake operon file, write standard output

Usage:
    perl $0 <specise_data_dir>

Example:
    perl $0 example/ncbi_data/Bacillus_subtilis_168_uid57675

HERE

unless (@ARGV) {
    print $usage and die;
}

my $spe = pop @ARGV;
my %size;
opendir SPE, $spe or die "Cannot opendir $spe: $!";
foreach my $f (readdir SPE) {
    next unless $f =~ /\.faa/;

    $size{$f} = -s "$spe/$f";
}
close SPE;
#print Dumper \%size;

my @ncs = reverse sort {$size{$a} <=> $size{$b}} (keys %size);

my $count = 1;
foreach (@ncs) {
    open IN, "$spe/$_" or die "Cannot open $spe/$_: $!";
    while(<IN>) {
	chomp;
	next unless /^>gi\|([0-9]+)\|/;
	print "$count: $1\n";
	$count++;
    }
    close IN;
}
