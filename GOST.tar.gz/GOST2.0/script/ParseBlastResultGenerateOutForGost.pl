#the script used to identify the .out file for GOST base on the blast results, furthermore get RBH results if -t 1
#!/usr/bin/perl -w
use strict;
#use Data::Dumper;
#set the parameters
if (!$ARGV[0]) { print "the script used to identify the initial Homolog Graph for GOST base on the blast results\nperl ParseBlastResultGenerateOutForGost.pl \n-n NC_number \n-e evalue_cutoff(0.001) \n-s similarity_cutoff(0.2) \n-b blast_TtoR_file \n-r blast_RtoT_file \n-t top_n_hits(default no input, 1 for RBH) \n-o output_folder\n"; die ;}
my ($OutPutFolder,$similarity_cutoff,$blastT2R,$blastR2T,$evalue_cutoff,$NCname,$BestHitNum);
for (my $i=0; $i<@ARGV; ++$i) {
    if ($ARGV[$i] eq "-o") {if ($ARGV[$i+1]) {$OutPutFolder = $ARGV[$i+1];}   else {print "wrong input format (-i)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-s") {if ($ARGV[$i+1]) {$similarity_cutoff = $ARGV[$i+1];}   else {print "wrong input format (-s)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-b") {if ($ARGV[$i+1]) {$blastT2R = $ARGV[$i+1];}   else {print "wrong input format (-b)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-r") {if ($ARGV[$i+1]) {$blastR2T = $ARGV[$i+1];}   else {print "wrong input format (-r)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-e") {if ($ARGV[$i+1]) {$evalue_cutoff = $ARGV[$i+1];}   else {print "wrong input format (-e)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-n") {if ($ARGV[$i+1]) {$NCname = $ARGV[$i+1];}   else {print "wrong input format (-n)\n"; printmanul(); die "exit.\n";} }
    if ($ARGV[$i] eq "-t") {if ($ARGV[$i+1]) {$BestHitNum = $ARGV[$i+1];}   else {print "wrong input format (-t)\n"; printmanul(); die "exit.\n";} }
}

my (@compare_bitscore,$query_gene,@sorted_bitscore,$flag_push_bitscore,@compare_hit);
my (%hash_evalue,%hash_bitscore,%hash_evalue_2);
my (@best_hit_EtoO,@best_hit_OtoE);
my ($top_n,$flag_top);
#-----------------------------------------------------------------------------------------------------------------------------------------------
#parse the file blastT2R
#-----------------------------------------------------------------------------------------------------------------------------------------------
open (BB,"$blastT2R");
my $flag_compare = 0;
while (my $line = <BB>){
    chomp $line;
    my @temp0 = split (/\t/,$line);
    #get the GI from the blast result
    if ($temp0[10] < $evalue_cutoff){
	my @temp1 = split (/\|/,$temp0[0]);
	my @temp2 = split (/\|/,$temp0[1]);
	my $hit = join (',',$temp1[1],$temp2[1]);
	#if the matches are same, pick the smaller evalue and the larger bit score
	if (!(($hash_evalue{$hit})&&($hash_bitscore{$hit}))){
	    $hash_evalue{$hit} = $temp0[10];
	    $hash_bitscore{$hit} = $temp0[11];
	    @compare_bitscore = ();
	}
	elsif ($temp0[10] < $hash_evalue{$hit}){
	    $hash_evalue{$hit} = $temp0[10];
	    if (($hash_bitscore{$hit})&&($temp0[11] > $hash_bitscore{$hit})){
		$hash_bitscore{$hit} = $temp0[11];
	    }
	}
	#compare the bit score with the same query gene
	if ($temp1[1] eq $query_gene){
	    if (($top_n < $BestHitNum)&&($BestHitNum)){
		push (@compare_hit,$hit);
		$top_n++;
	    }
	    elsif (!($BestHitNum)){
		push (@compare_hit,$hit);
	    }
	}
	else {
	    $top_n = 0;
	    #for the first line of a file
	    if ($flag_compare == 0){
		push (@compare_hit,$hit);
		$top_n++;
		$query_gene = $temp1[1];
		$flag_compare = 1;
	    }
	    else{
		for (my $i=0; $i<@compare_hit; $i++){
		    push (@compare_bitscore,$hash_bitscore{$compare_hit[$i]});
		}
		@sorted_bitscore = sort {$b <=> $a} @compare_bitscore;
		if ($sorted_bitscore[0]){
		    for (my $i=0; $i<@compare_hit; $i++){
			my $cut = $similarity_cutoff * $sorted_bitscore[0];
			my $very_same_bitscore = $sorted_bitscore[0]-$compare_bitscore[$i];
			if (($very_same_bitscore <= $cut)){
			    push (@best_hit_EtoO,$compare_hit[$i]);
			}
		    }
		}
		$query_gene = $temp1[1];
		@compare_bitscore = ();
		@compare_hit = ();
		push (@compare_hit,$hit);
		$top_n++;
		$flag_push_bitscore = 0;
		$flag_top = 0;
	    }
	}
    }
}
for (my $i=0; $i<@compare_hit; $i++){
    push (@compare_bitscore,$hash_bitscore{$compare_hit[$i]});
}
@sorted_bitscore = sort {$b <=> $a} @compare_bitscore;
if ($sorted_bitscore[0]){
    for (my $i=0; $i<@compare_hit; $i++){
	my $cut = $similarity_cutoff * $sorted_bitscore[0];
	my $very_same_bitscore = $sorted_bitscore[0]-$compare_bitscore[$i];
	if ($very_same_bitscore <= $cut){
	    push (@best_hit_EtoO,$compare_hit[$i]);
	}
    }
}
@compare_hit = ();
@compare_bitscore = ();
@sorted_bitscore = ();
close BB;

#-----------------------------------------------------------------------------------------------------------------------------------------------
#get @best_hit_EtoO and $hash_evalue
#-----------------------------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------------------------------------------------------
#parse the file blastR2T
#-----------------------------------------------------------------------------------------------------------------------------------------------

open (AA,"$blastR2T");
$flag_compare = 0;
while (my $line = <AA>){
    chomp $line;
    my @temp0 = split (/\t/,$line);
    if ($temp0[10] < $evalue_cutoff){
	my @temp1 = split (/\|/,$temp0[0]);
	my @temp2 = split (/\|/,$temp0[1]);
	my $hit = join (',',$temp2[1],$temp1[1]);
	if (!(($hash_evalue_2{$hit})&&($hash_bitscore{$hit}))){
	    $hash_evalue_2{$hit} = $temp0[10];
	    $hash_bitscore{$hit} = $temp0[11];
	    @compare_bitscore = ();
	}
	elsif($temp0[10] < $hash_evalue_2{$hit}){
	    $hash_evalue_2{$hit} = $temp0[10];
	    if (($hash_bitscore{$hit})&&($temp0[11] > $hash_bitscore{$hit})){
		$hash_bitscore{$hit} = $temp0[11];
	    }
	}
	if ($temp1[1] eq $query_gene){
	    if (($top_n < $BestHitNum)&&($BestHitNum)){
		push (@compare_hit,$hit);
		$top_n++;
	    }
	    elsif (!($BestHitNum)){
		push (@compare_hit,$hit);
	    }
	}
	else {
	    $top_n = 0;
	    if ($flag_compare == 0){
		push (@compare_hit,$hit);
		$top_n++;
		$query_gene = $temp1[1];
		$flag_compare = 1;
	    }
	    else{
		for (my $i=0; $i<@compare_hit; $i++){
		    push (@compare_bitscore,$hash_bitscore{$compare_hit[$i]});
		}
		@sorted_bitscore = sort {$b <=> $a} @compare_bitscore;
		if ($sorted_bitscore[0]){
		    for (my $i=0; $i<@compare_hit; $i++){
			my $cut = $similarity_cutoff * $sorted_bitscore[0];
			my $very_same_bitscore = $sorted_bitscore[0]-$compare_bitscore[$i];
			if ($very_same_bitscore <= $cut){
			    push (@best_hit_OtoE,$compare_hit[$i]);
			}
		    }
		}
		$query_gene = $temp1[1];
		@compare_bitscore = ();
		@compare_hit = ();
		push (@compare_hit,$hit);
		$top_n++;
		$flag_push_bitscore = 0;
	    }
	}
    }
}
for (my $i=0; $i<@compare_hit; $i++){
    push (@compare_bitscore,$hash_bitscore{$compare_hit[$i]});
}
@sorted_bitscore = sort {$b <=> $a} @compare_bitscore;
if ($sorted_bitscore[0]){
    for (my $i=0; $i<@compare_hit; $i++){
	my $cut = $similarity_cutoff * $sorted_bitscore[0];
	my $very_same_bitscore = $sorted_bitscore[0]-$compare_bitscore[$i];
	if ($very_same_bitscore <= $cut){
	    push (@best_hit_OtoE,$compare_hit[$i]);
	}
    }
}
close AA;

#-----------------------------------------------------------------------------------------------------------------------------------------------
#get @best_hit_OtoE and $hash_evalue_2
#-----------------------------------------------------------------------------------------------------------------------------------------------


my @best_hit_intersection;
#-----------------------------------------------------------------------------------------------------------------------------------------------
# if we need RBH we use @best_hit_intersection = grep ($OtoE{$_}, @best_hit_EtoO); 
# if we need homology graph we use @best_hit_intersection = (@best_hit_EtoO,@best_hit_EtoO);
# @uniq_best_hits is @best_hit_intersection without duplication
#-----------------------------------------------------------------------------------------------------------------------------------------------

if ($BestHitNum == 1){
    my %EtoO = map {$_ => 1} @best_hit_EtoO;
    my %OtoE = map {$_ => 1} @best_hit_OtoE;
    @best_hit_intersection = grep ($OtoE{$_}, @best_hit_EtoO);
}else{
    ####we get the union set of the two arrays instead of overlap#### 
    @best_hit_intersection = (@best_hit_EtoO,@best_hit_EtoO);
}
my (@uniq_best_hits,%compare_best_hits);
@uniq_best_hits = grep { ! $compare_best_hits { $_ }++ } @best_hit_intersection;


#-----------------------------------------------------------------------------------------------------------------------------------------------
# print the results
#----------------------------------------------------------------------------------------------------------------------------------------------

#print Dumper \@uniq_best_hits;
### Orignal code ####
####if ( !(-e "$OutPutFolder") ) { system ("mkdir $OutPutFolder"); }
####if (-e "$OutPutFolder/$NCname.out.tp") { system ("rm $OutPutFolder/$NCname.out.tp"); }
####open (CC,">>$OutPutFolder/$NCname.out.tp");
####for (my $j=0; $j<@uniq_best_hits; $j++){
####	my @GI = split (/,/,$uniq_best_hits[$j]);
####	my $revalue = join (',',$GI[1],$GI[0]);
####
####	#do not consider the edges without $hash_evalue or $hash_evalue_2
####	if (($hash_evalue{$uniq_best_hits[$j]})&&($hash_evalue_2{$uniq_best_hits[$j]})){
####		print CC "$GI[0]: \($GI[1],$hash_evalue{$uniq_best_hits[$j]},$hash_evalue_2{$uniq_best_hits[$j]}\)\n";
####	}
####}
####close CC;

### changed by Chuan

if ( !(-e "$OutPutFolder") ) { system ("mkdir $OutPutFolder"); }
if (-e "$OutPutFolder/$NCname.out.tp") { system ("rm $OutPutFolder/$NCname.out.tp"); }
open (CC,">>$OutPutFolder/$NCname.out.tp");
my %gi2refs;
foreach (@uniq_best_hits) {
    my @GI = split (/,/,$_);
    push @{$gi2refs{$GI[0]}}, $GI[1];
}

foreach my $tar (keys %gi2refs) {
    my @to_print;
    foreach my $ref (@{$gi2refs{$tar}}) {
	my $uniq_hits = join (',',$tar, $ref);
	my $revalue = join (',', $ref, $tar);
	if (($hash_evalue{$uniq_hits})&&($hash_evalue_2{$uniq_hits})){

	    push @to_print, "\($ref,$hash_evalue{$uniq_hits},$hash_evalue_2{$uniq_hits}\)";
	}
    }
    if(@to_print) {
	print CC "$tar: ", (join "\t", @to_print), "\n";
    }
}


##for (my $j=0; $j<@uniq_best_hits; $j++){
##    my @GI = split (/,/,$uniq_best_hits[$j]);
##    my $revalue = join (',',$GI[1],$GI[0]);
##
##    #do not consider the edges without $hash_evalue or $hash_evalue_2
##    if (($hash_evalue{$uniq_best_hits[$j]})&&($hash_evalue_2{$uniq_best_hits[$j]})){
##	print CC "$GI[0]: \($GI[1],$hash_evalue{$uniq_best_hits[$j]},$hash_evalue_2{$uniq_best_hits[$j]}\)\n";
##    }
##}
##close CC;
