# the script is used to combine the mlutiple faa files, if any, of a same species
#! /usr/bin/perl -w
use strict;

my ($file_list, $speciesdir, $outputdir);
if (!$ARGV[0]) { print "the script is used to combine the faa files, if any, of a same species\nperl combine_faafile.pl -i files_list_faa -j faadir -o faa_combined_dir\n"; die ;}
for (my $i=0; $i<@ARGV; ++$i) {
        if ($ARGV[$i] eq "-i") {if ($ARGV[$i+1]) {$file_list = $ARGV[$i+1];}         else {print "wrong input format (-i)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-j") {if ($ARGV[$i+1]) {$speciesdir = $ARGV[$i+1];}         else {print "wrong input format (-j)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-o") {if ($ARGV[$i+1]) {$outputdir = $ARGV[$i+1];}         else {print "wrong input format (-o)\n"; printmanul(); die "exit.\n";} }
}

open (fp, "$file_list") || die "$!";
chomp (my @species_list = <fp>);
close fp;

my ($species_max, $species_max_NC, $end_pos);
for (my $i = 0; $i < @species_list; $i++){
	chomp (my @species_temp = split (/\t/,$species_list[$i]));
	if ($i ==0 ){
		$species_max = $species_temp[0];
		$species_max_NC = $species_temp[2];
		if (-e "$outputdir/$species_max_NC.faa"){
			system ("rm $outputdir/$species_max_NC.faa");
		}
		open (fp2, "$speciesdir/$species_temp[2].faa") || die "Cannot open $speciesdir/$species_temp[2].faa: $!";
		chomp (my @aa = <fp2>);
		close fp2;
		open (fp1, ">>$outputdir/$species_temp[2].faa")||die "$!";
		for (my $j = 0; $j < @aa; $j++){
			print fp1 "$aa[$j]\n";
		}
	}else{
		if ($species_temp[0] eq $species_max){
			open (fp2, "$speciesdir/$species_temp[2].faa");
	                chomp (my @aa = <fp2>);
	                close fp2;
			for (my $j = 0; $j < @aa; $j++){
				print fp1 "$aa[$j]\n";
			}

		}else{
			close fp1;
			$species_max = $species_temp[0];
			$species_max_NC = $species_temp[2];
			if (-e "$outputdir/$species_max_NC.faa"){
	                        system ("rm $outputdir/$species_max_NC.faa");
	                }
			open (fp2, "$speciesdir/$species_temp[2].faa"); 
	                chomp (my @aa = <fp2>);
        	        close fp2;
	                open (fp1, ">>$outputdir/$species_temp[2].faa")||die "$!";
        	        for (my $j = 0; $j < @aa; $j++){
        	                print fp1 "$aa[$j]\n";
               		}
		}
	}
}
close fp1;
