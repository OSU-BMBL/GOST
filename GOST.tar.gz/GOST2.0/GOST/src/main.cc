/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, May. 10, 2010
* Usage: the main process of the project
*/

#include "../include/edge_file_reader.h"
#include "../include/edge_set_matrix.h"
#include "../include/matching_file_writer.h"
#include "../include/operon_dynamic_graph.h"
#include "../include/operons_in_genome.h"
#include "../include/rbh.h"

template<typename gene_t> Rbh<gene_t, double> BipartiteGraphRbhMerger<gene_t>::rbh_;
template<typename gene_t> std::map<gene_pair_t, WeightPair> BipartiteGraphCloseRbhMerger<gene_t>::reader_;

const char* SetFileName(const int argc, char* argv[], const int i, const char* default_filename) {
  return (argc > i) ? argv[i] : default_filename;
}

void Push(const std::map<OperonId, std::pair<std::set<OperonId>, std::set<OperonId> > >& gost_edge, std::map<OperonId, std::map<OperonId, int> >* gost_second_edge_pointer) {
  for (std::map<OperonId, std::pair<std::set<OperonId>, std::set<OperonId> > >::const_iterator it = gost_edge.begin(); it != gost_edge.end(); it++) {
    const std::set<OperonId>& set = it->second.first;
    if (set.size() == 1) {
      (*gost_second_edge_pointer)[*set.begin() + 1][*set.begin() + 1]++;
      continue;
    }
    for (std::set<OperonId>::const_iterator jt = set.begin(); jt != set.end(); jt++) {
      std::set<OperonId>::const_iterator kt = jt;
      for (kt++; kt != it->second.first.end(); kt++) {
        (*gost_second_edge_pointer)[*jt + 1][*kt + 1]++;
        (*gost_second_edge_pointer)[*kt + 1][*jt + 1]++;
      }
    }
  }
}


int main(int argc, char *argv[]) {
  uglyTime(NULL);
  const std::string kUsage = "Usage: %s <FileU> <FileV> <File_Edge> <RBH_OUTPUT_File> <GOST_OUTPUT_File> edge-cutoff\n";  // ..\data_test\Escherichia_coli_K12.gi.operon ..\data_test\NC_000853.gi.operon ..\data_test\NC_000853.out ..\output\NC_000853.RBH ..\output\NC_000853.GOST 
  if (argc < 6){
    puts ("Usage: ./GOST <FileU> <FileV> <File_Edge> <RBH_OUTPUT_File> <GOST_OUTPUT_File> edge-cutoff(optional)\n");
    exit (1);
  }
  double similarity;
  if (!argv[6])
    	similarity = 0.001;
  else
	similarity = atof(argv[6]);
  const int file_num = 1;
  const char* file_u = argv[1];
  const char* file_v[file_num]; file_v[0] = argv[2];
  const char* edge_file[file_num]; edge_file[0] = argv[3];
  const char* rbh_file[file_num]; rbh_file[0] = argv[4];
  const char* gost_file[file_num]; gost_file[0] = argv[5]; 
  OperonsGenes operons_u;
  file_handler::ReadOperonFile(file_u, &operons_u);
  std::map<OperonId, std::map<OperonId, int> > gost_second_edge_map;
  for (int i= 0; i < file_num; i++) {
    printf("Begin to analysis orthology between %s and %s\n",file_u, file_v[i]);	  
    OperonsGenes operons_v;
    file_handler::ReadOperonFile(file_v[i], &operons_v);
    std::map<gene_pair_t, WeightPair> reader;
    if (!argv[6])
	    similarity = 0.001;
    //edge_file_reader::Read(edge_file[i], 0.001, &reader);
    edge_file_reader::Read(edge_file[i], similarity, &reader);

    //find orthology by rbh
    BipartiteGraphRbhMerger<gene_t>::rbh_.LoadMap(reader);
    BipartiteGraphRbhMerger<gene_t>::rbh_.Init();
    std::set<gene_pair_t> rbh_gp;
    BipartiteGraphRbhMerger<gene_t>::rbh_.SaveGenePairSet(&rbh_gp);
    file_handler::WriteMatchingFile(reader, rbh_gp, rbh_file[i]);
    uglyTime("Orthologous gene pairs identified by RBH are writen to %s", rbh_file[i]);
    
    //find orthology by gost	
    OperonDynamicGraph<BipartiteGraphRbhMerger<gene_t> > dynamic_graph_rbh(reader, operons_u, operons_v);
    	//first true means compare by evalues when the maximal weight equals 1
    	//second true means sort the elements by a faster way
    dynamic_graph_rbh.Init(true, true);
    std::set<gene_pair_t> gost_rbh_gp;
    dynamic_graph_rbh.GetGenePairSet(&gost_rbh_gp);
    file_handler::WriteMatchingFile(reader, gost_rbh_gp, gost_file[i]);
    uglyTime("Orthologous gene pairs identified by GOST are writen to %s", gost_file[i]);
  }

}
