#ifndef GOST_EDGE_WEIGHT_H_
#define GOST_EDGE_WEIGHT_H_
#include <set>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <math.h>
#include <ctype.h>
#include <stdarg.h>
#include <limits.h>

#include "gene_set_type.h"
#include "bipartite_graph.h"
template <typename M> class EdgeWeight {
public:
  EdgeWeight(const std::pair<std::set<OperonId>, std::set<OperonId> > & name_set_value, const std::set<std::pair<gene_pair_t, WeightPair> >& edge_set_value, const size_t& weight_value, typename std::list<BipartiteGraph<gene_t, M> >::iterator temp1, typename std::list<BipartiteGraph<gene_t, M> >::iterator temp2) : edge_name_set_(name_set_value), weight_(weight_value), edge_set_(edge_set_value) {
    main_iterator_ = temp1;
    secondary_iterator_ = temp2;
  }
  //static bool slow_compare(const EdgeWeight& first, const EdgeWeight& second) {
  // if (first.weight_ > second.weight_) return true;
  // if (first.weight_ < second.weight_) return false;
  // if (first.weight_ == 1) return first.edge_set_.begin()->second.first < second.edge_set_.begin()->second.first;  // Unbearable slow!!!!!!!!!!
  // return (first.edge_set_.size() < second.edge_set_.size());
  //}
  static bool slow_compare(const EdgeWeight& first, const EdgeWeight& second) {
    if (first.weight_ > second.weight_) return true;
    if (first.weight_ < second.weight_) return false;
    //first by weight, then by edge_set_.size, then by edge_set_.begin()->second.first
    //if (first.weight_ == 1 && first.edge_set_.size() == second.edge_set_.size()) return first.edge_set_.begin()->second.first < second.edge_set_.begin()->second.first;  
    //first by weight, then by edge_set_.begin()->second.first
    if (first.weight_ == 1) return first.edge_set_.begin()->second.first < second.edge_set_.begin()->second.first;  // Unbearable slow!!!!!!!!!!
    return (first.edge_set_.size() < second.edge_set_.size());
  }
  static bool compare(const EdgeWeight& first, const EdgeWeight& second) {
   if (first.weight_ > second.weight_) return true;
   if (first.weight_ < second.weight_) return false;
   return (first.edge_set_.size() < second.edge_set_.size());
  }
  void Update(const std::pair<std::set<OperonId>, std::set<OperonId> > & name_set_value, const std::set<std::pair<gene_pair_t, WeightPair> >& edge_set_value, const size_t& weight_value, typename std::list<BipartiteGraph<gene_t, M> >::iterator iterator1, typename std::list<BipartiteGraph<gene_t, M> >::iterator iterator2) {
    edge_name_set_ = name_set_value;
    weight_ = weight_value;
    edge_set_ = edge_set_value;
    main_iterator_ = iterator1;
    secondary_iterator_ = iterator2;
  }
  const std::pair<std::set<OperonId>, std::set<OperonId> > & edge_name_set() const {
    return edge_name_set_;
  }
  const std::set<std::pair<gene_pair_t, WeightPair> >& edge_set() const {
    return edge_set_;
  }
  size_t weight() const {
    return weight_;
  }
  mutable typename std::list<BipartiteGraph<gene_t, M> >::iterator main_iterator_, secondary_iterator_;
private:
  std::pair<std::set<OperonId>, std::set<OperonId> > edge_name_set_; // edge name between vertex 1 and 2 (operon code)
  std::set<std::pair<gene_pair_t, WeightPair> > edge_set_; // the true edge list of gene pairs
  size_t weight_; // weight between the vertices
};

long clock1000()
/* A millisecond clock. */
{
    struct timeval tv;
    static long origSec;
    gettimeofday(&tv, NULL);
    if (origSec == 0) origSec = tv.tv_sec;
    return (tv.tv_sec-origSec)*1000 + tv.tv_usec / 1000;
}

void uglyTime(char *label, ...)
/* Print label and how long it's been since last call.  Call with 
 * a NULL label to initialize. */
{
    static long lastTime = 0;
    long time = clock1000();
    va_list args;
    va_start(args, label);
    if (label != NULL)
    {
        vfprintf(stdout, label, args);
        fprintf(stdout, " [%.3f seconds elapsed]\n", (time - lastTime)/1000.);
    }
    lastTime = time;
    va_end(args);
}


#endif // GOST_EDGE_WEIGHT_H_
