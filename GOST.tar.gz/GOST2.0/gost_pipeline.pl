#!/usr/bin/perl
#
#Description: This is a pipe line for gost, from the NCBI data and operon predicted
#by DOOR( or same format ), generate an ortholog relationship between two species
#	
#

use strict;
use warnings;
use Data::Dumper;

my $usage = <<HERE;
This is a pipe line for GOST to generate an orthology mapping between two given species, using ".faa" files from NCBI and operon prediction in required format\

Input format:
species_directory: the directory containing the species information downloaded from NCBI
operon format:
1: 16077069 
2: 16077070 
3: 16077071 16077072 255767014 
4: 16077074 
...

Output:
Two orhtology mapping prediction with the method GOST and RBH, and a simple comparison between them

Usage:
\$ perl $0 <target_species_dir> <ref_species_dir> <output_dir> <optional: target_operon> <optional: ref_operon>\

Example:
\$ perl $0 example/ncbi_data/Escherichia_coli_K_12_substr__MG1655_uid57779/ example/ncbi_data/Clostridium_botulinum_B_Eklund_17B_uid59159/ example_output example/operon/Ecoli.opr example/operon/NC_010674.opr 

If you don't have operon files, we will generate fake operon files with fake_operon.pl based on the ".faa" files:\
\$ perl $0 example/ncbi_data/Escherichia_coli_K_12_substr__MG1655_uid57779/ example/ncbi_data/Clostridium_botulinum_B_Eklund_17B_uid59159/ example_output_no_opr

HERE

unless (@ARGV > 2) {
    print $usage;
    exit(1);
}

my ($spe1, $spe2, $output_dir, $opr1, $opr2,  $evalue) = @ARGV;

$evalue or $evalue = 0.001;

#my $tmp_dir = "tmpdata"."22895";
my $tmp_dir = "tmpdata".$$;

### mkdir for tmp data  and output###
mkdir $tmp_dir unless -e $tmp_dir;

mkdir $output_dir unless -e $output_dir;

### combine faa data ####
open OUT, ">$tmp_dir/file_for_combine" or die "Cannot open $tmp_dir/file_for_combine:$!";

mkdir "$tmp_dir/faa";
mkdir "$tmp_dir/faa_combine";

my %spe2nc;
for my $spe ($spe1, $spe2) {
    #print $spe, "\n";
    my %size;
    opendir SPE, $spe or die "Cannot opendir $spe: $!";
    foreach my $f (readdir SPE) {
	next unless $f =~ /\.faa/;

	symlink "../../$spe/$f", "$tmp_dir/faa/$f";
	$size{$f} = -s "$spe/$f";
    }
    close SPE;
    #print Dumper \%size;

    my @ncs = reverse sort {$size{$a} <=> $size{$b}} (keys %size);
    $spe2nc{$spe} = $ncs[0];

    foreach (@ncs) {
	print OUT "$spe\t$size{$_}";
	$_ =~ s/\.faa//;
	print OUT "\t$_\n";
    }
}

close OUT;
    
system "perl script/combine_faafile.pl -i $tmp_dir/file_for_combine -j $tmp_dir/faa -o $tmp_dir/faa_combine";

my $nc1 = $spe2nc{$spe1};
my $nc2 = $spe2nc{$spe2};

### generate fake operon ####
if(!$opr1 or !$opr2) {
    my $fake_opr_cmd = "perl script/fake_operon.pl $spe1 > $tmp_dir/fake_opr1\n\
    perl script/fake_operon.pl $spe2 > $tmp_dir/fake_opr2";
    system($fake_opr_cmd);
    $opr1 = "$tmp_dir/fake_opr1";
    $opr2 = "$tmp_dir/fake_opr2";
}


#### mutally blast ##### 
#print "Running blast\n";
my $blast_cmd = <<HERE;
for i in $tmp_dir/faa_combine/*
do
    formatdb -i \$i
done

blastall -p blastp -i $tmp_dir/faa_combine/$nc1 -d $tmp_dir/faa_combine/$nc2 -F "m S" -s T -v 10000 -b 10000 -m 8 -e 0.01  -o $tmp_dir/$nc1\_$nc2.blast

blastall -p blastp -i $tmp_dir/faa_combine/$nc2 -d $tmp_dir/faa_combine/$nc1 -F "m S" -s T -v 10000 -b 10000 -m 8 -e 0.01  -o $tmp_dir/$nc2\_$nc1.blast

HERE

system($blast_cmd);

### parse blast result to homology for gost
my $parse_cmd = <<HERE;
perl script/ParseBlastResultGenerateOutForGost.pl -n $nc2 -b $tmp_dir/$nc1\_$nc2.blast -r $tmp_dir/$nc2\_$nc1.blast -e 0.001 -s 0.2 -o $tmp_dir
HERE

system($parse_cmd);
    
### GOST ###
#print "Running GOST\n";
my $nc1_tmp = $nc1;
my $nc2_tmp = $nc2;
$nc1 =~ s/\.faa//;
$nc2 =~ s/\.faa//;
my $gost_cmd = <<HERE;
GOST/build/bin/GOST $opr1 $opr2 $tmp_dir/$nc2_tmp.out.tp $output_dir/$nc1\.$nc2.RBH $output_dir/$nc1\.$nc2.GOST $evalue
HERE
#print "$gost_cmd\n";
system($gost_cmd);

### some basic compare between RBH and gost ###
my $compare_cmd = "perl script/gost_vs_rbh.pl $output_dir/$nc1\.$nc2.GOST $output_dir/$nc1\.$nc2.RBH > $output_dir/$nc1\.$nc2.stat";
system($compare_cmd);

unlink "formatdb.log";
system("rm -rf $tmp_dir");
